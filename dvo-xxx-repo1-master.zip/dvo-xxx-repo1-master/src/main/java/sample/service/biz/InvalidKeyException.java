package sample.service.biz;

@SuppressWarnings("serial")
public class InvalidKeyException extends Exception {
	
	public InvalidKeyException(String msg) {
		super(msg);
	}
	
}
