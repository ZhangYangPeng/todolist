package sample.service.biz;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;

import sample.service.util.ServiceUtils;

/**
 * 契約情報サービス
 */
@ApplicationScoped
public class ContractService {

	// 契約情報
	List<Map<String, Object>> contractInfo;

	/**
	 * サービス初期化処理
	 */
	@PostConstruct
	public void init() {
		// 注意 : サンプルのため手動で値を設定しています。
		contractInfo = new ArrayList<Map<String, Object>>();

		// Entry1
		Map<String, Object> ent1 = new LinkedHashMap<String, Object>();
		ent1.put("cid", "11111");
		ent1.put("name", "田中一郎");
		ent1.put("mail", "tana@sample.com");
		contractInfo.add(ent1);

		// Entry2
		Map<String, Object> ent2 = new LinkedHashMap<String, Object>();
		ent2.put("cid", "26334");
		ent2.put("name", "山本圭介");
		ent2.put("mail", "yamamoto@sample.com");
		contractInfo.add(ent2);

		// Entry3
		Map<String, Object> ent3 = new LinkedHashMap<String, Object>();
		ent3.put("cid", "51112");
		ent3.put("name", "鈴木涼子");
		ent3.put("mail", "suzuki@sample.com");
		contractInfo.add(ent3);

		// Entry4
		Map<String, Object> ent4 = new LinkedHashMap<String, Object>();
		ent4.put("cid", "88888");
		ent4.put("name", "金井昌幸");
		ent4.put("mail", "kanai@sample.com");
		contractInfo.add(ent4);

		// Entry5
		Map<String, Object> ent5 = new LinkedHashMap<String, Object>();
		ent5.put("cid", "99999");
		ent5.put("name", "鈴木義孝");
		ent5.put("mail", "suzuki.kei@sample11.com");
		contractInfo.add(ent5);

		// Entry6
		Map<String, Object> ent6 = new LinkedHashMap<String, Object>();
		ent5.put("cid", "77777");
		ent5.put("name", "鈴木太郎");
		ent5.put("mail", "suzuki.taro@sample11.com");
		contractInfo.add(ent6);
	}


	/**
	 * 契約情報の照会
	 */
    public Map<String, Object> retreive(Map<String, Object> inMap) throws InvalidKeyException, NoSuchDataException {

    	// key
    	String key = (String) inMap.get("cid");
    	validateKey(key);

    	// return object
    	Map<String, Object> ret = null;

    	// search
    	int max = contractInfo.size();
    	for (int i = 0; i < max; i++) {
    		Map<String, Object> map = contractInfo.get(i);
    		if (key.equals((String) (map.get("cid")))) {
    			ret = map;
    			break;
    		} else if (i == (max-1)) {
    			// not found
    			throw new NoSuchDataException("No data with cid=" + key);
    		}
    	}

        return ret;
    }

    /**
     * 検索キー値の検証
     */
    void validateKey(String key) throws InvalidKeyException {
    	if (key == null || key.length() != 5 || !ServiceUtils.isAllDigit(key)) {
    		throw new InvalidKeyException("Invalid cid. cid=" + key);
    	}
    }

}
