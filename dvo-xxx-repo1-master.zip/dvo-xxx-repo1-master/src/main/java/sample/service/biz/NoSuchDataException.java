package sample.service.biz;

@SuppressWarnings("serial")
public class NoSuchDataException extends Exception {
	
	public NoSuchDataException(String msg) {
		super(msg);
	}

}
