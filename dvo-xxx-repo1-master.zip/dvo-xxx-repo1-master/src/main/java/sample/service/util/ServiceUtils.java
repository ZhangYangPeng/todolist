package sample.service.util;

import java.util.regex.Pattern;

/**
 * ユーティリティクラス
 */
public class ServiceUtils {
	
	/**
	 * 文字列が全て数字であるかどうかをチェックする。
	 */
	public static boolean isAllDigit(String str) {
		return Pattern.matches("^[\\d]+$", str);
	}
	
	/**
	 * 文字列に含まれる全ての全角数字を半角数字に変換する。
	 */
	public static String convertFullWidthDigitToHalfWidthDigit(String str) {
		String result = str;
		if(str != null) {
		    StringBuilder sb = new StringBuilder(str);
		    for (int i = 0; i < sb.length(); i++) {
		        int c = (int) sb.charAt(i);
		        if (c >= 0xFF10 && c <= 0xFF19) {
		            sb.setCharAt(i, (char) (c - 0xFEE0));
		        }
		    }
		    result = sb.toString();
		}
	    return result;
	}

}
