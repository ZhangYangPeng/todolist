package sample.rest.biz;

import java.util.LinkedHashMap;
import java.util.Map;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import sample.service.biz.InvalidKeyException;

/**
 * 例外マッピング（InvalidKeyException）
 */
@Provider
public class InvalidKeyExceptionMapper implements ExceptionMapper<InvalidKeyException> {
	
	// Response Media Type
	private static final String MEDIA_TYPE = "application/problem+json;charset=UTF-8"; 
	
	/**
	 * toResponse
	 */
	@Override
	public Response toResponse(InvalidKeyException ike) {

		// Construct Error Data
		Map<String, String> errMap = new LinkedHashMap<String, String>();
		errMap.put("error", ike.getMessage());
		
		// Build Response
		Response resp = Response.status(Status.BAD_REQUEST) // 400
				.entity(errMap)
				.type(MEDIA_TYPE)
				.build();
		
		return resp;
	}
	
}
