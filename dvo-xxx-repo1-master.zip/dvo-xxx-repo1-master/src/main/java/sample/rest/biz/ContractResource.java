package sample.rest.biz;

import java.util.Map;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import sample.service.biz.ContractService;
import sample.service.biz.InvalidKeyException;
import sample.service.biz.NoSuchDataException;

/**
 * 契約情報リソース
 */
@Path("contract")
public class ContractResource {

	@Inject
	private ContractService service;

	/**
	 * 契約情報の照会
	 */
	@POST
	@Path("retrieve")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Map<String, Object> retrieve(Map<String, Object> inMap) throws InvalidKeyException, NoSuchDataException {
		return service.retreive(inMap);
	}
}
