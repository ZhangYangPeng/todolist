package sample.rest.biz;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("biz")
public class BusinessApplication extends Application {

	@Override
	public Set<Class<?>> getClasses() {
		HashSet<Class<?>> set = new HashSet<Class<?>>();
		set.add(ContractResource.class);
		set.add(InvalidKeyExceptionMapper.class);
		set.add(NoSuchDataExceptionMapper.class);

		// CheckStyle Custom Rule Test
		// 文字列比較で定数値比較の際は定数値.equalsとなっているかの確認
		// エラーメッセージ
		// CheckUseStringliteralEqualsMethod: 文字列リテラルと文字列オブジェクトの比較には、文字列リテラルのequals()メソッドを使用してください。
		String a = "10";
		if(a.equals("10")){
			// Findbugs Test
			// 意味なくExceptionクラスを生成するとエラーとなる
			// エラーメッセージ
			// new Exception() をスローしていません。
			// ただし、findbugs-excludefilter.xmlが指定された場合はこのエラーは検出対象外となる
			new Exception();

			// Customrule Test
			// ThreadGroupを使用するとエラーとなる
			// エラーメッセージ
			// ThreadGroupクラスは安全面に不備があるため、使用しない。
			new ThreadGroup("Chief").activeCount();
		}
		return set;
	}

}
