package sample.rest.biz;

import java.util.LinkedHashMap;
import java.util.Map;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import sample.service.biz.NoSuchDataException;

/**
 * 例外マッピング（NoSuchDataException）
 */
@Provider
public class NoSuchDataExceptionMapper implements ExceptionMapper<NoSuchDataException> {
	
	/**
	 * toResponse
	 */
	@Override
	public Response toResponse(NoSuchDataException nsde) {

		// Construct Response Data
		Map<String, String> errMap = new LinkedHashMap<String, String>();
		errMap.put("message", nsde.getMessage());
		
		// Build Response
		Response resp = Response.status(Status.OK) //200
				.entity(errMap)
				.type(MediaType.APPLICATION_JSON)
				.build();
		
		return resp;
	}
	
}