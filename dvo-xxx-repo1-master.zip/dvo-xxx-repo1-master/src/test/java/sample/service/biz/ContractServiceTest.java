package sample.service.biz;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

@TestInstance(Lifecycle.PER_CLASS)
public class ContractServiceTest {
	
	ContractService service;
	
	@BeforeAll
	public void beforeAll() {
		service = new ContractService();
	}
	
	//TODO 残りのテストを追加
	
	@Nested
	class ValidateKey {
		
		@DisplayName("正常値")
		@ParameterizedTest
		@ValueSource(strings = {"12345", "67890"})
		void normal(final String input) {
			try {
				service.validateKey(input);
			} catch (InvalidKeyException e) {
				fail("key : " + input + " should be valid.", e);
			}
		}
		
		@DisplayName("異常値")
		@ParameterizedTest
		@ValueSource(strings = { "123", "123456" })
		void error(final String input) {
			InvalidKeyException ike = assertThrows(InvalidKeyException.class, () -> {
				service.validateKey(input);
			});
			assertEquals("Invalid cid. cid=" + input, ike.getMessage());
		}
	}
	
}
