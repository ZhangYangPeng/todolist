package sample.service.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

public class ServiceUtilsTest {
	
	@Nested
	class IsAllDigit {
		
		@DisplayName("正常値")
		@ParameterizedTest
		@ValueSource(strings = {"12345", "9", "00000", "09876", "99999999999999999999999"})
		void normal(final String input) {
			assertTrue(ServiceUtils.isAllDigit(input));
		}
		
		@DisplayName("異常値")
		@ParameterizedTest
		@ValueSource(strings = {"", "ABC", "0F0F0F0F", "123_456", "12 34"})
		void error(final String input) {
			assertTrue(!ServiceUtils.isAllDigit(input));
		}
	}
	
	@Nested
	class ConvertFullWidthDigitToHalfWidthDigit {
		
		@DisplayName("正常値")
		@ParameterizedTest
		@CsvSource({"０１２３４５６７８９, 0123456789", "12３45, 12345", "9９9９9, 99999",
					"12345, 12345", "ABCDE, ABCDE", "'  ', '  '"})
		void normal(final String input, final String expected) {
			assertEquals(expected, ServiceUtils.convertFullWidthDigitToHalfWidthDigit(input));
		}
		
		@DisplayName("null")
		@Test
		void normal01() {
			assertEquals(null, ServiceUtils.convertFullWidthDigitToHalfWidthDigit(null));
		}
		
		@DisplayName("空文字")
		@Test
		void normal02() {
			assertEquals("", ServiceUtils.convertFullWidthDigitToHalfWidthDigit(""));
		}
	}
	
}
