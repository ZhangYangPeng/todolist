#!/bin/sh
##
##

# Init
export SHELL_DIR=`dirname ${0}`
. ${SHELL_DIR}/init_proj_env.sh


# Change Directory
cd target


# Create Release on the GitHub
rslt_json=`curl -s -H "Authorization: token ${LIB_TOKEN}" -d @- http://pdbsiosm11.aflac.aflac.co.jp/api/v3/repos/${REPO}/releases << EOS
{
  "tag_name":"$BDID",
  "name":"$BDNUM",
  "body":"$BDBODY"
}
EOS`

# Extract Upload URL from Resultant JSON
upload_url=`echo $rslt_json | jq -r '.upload_url'`
upload_url="${upload_url%\{*}"


# Module copy for Veracode Jenkins
veracode_up_root=/var/jenkins_home/veracode
veracode_up_appl=${veracode_up_root}/${VERA_APPL_NAME}
veracode_up_file=${veracode_up_appl}/${APPL_NAME}.war

docker exec ${VERA_UP_DOCKER} mkdir ${veracode_up_root}
docker exec ${VERA_UP_DOCKER} mkdir ${veracode_up_appl}
docker cp ${APPL_NAME}.war ${VERA_UP_DOCKER}:${veracode_up_file}
docker exec --user root ${VERA_UP_DOCKER} chown jenkins ${veracode_up_file}
docker exec --user root ${VERA_UP_DOCKER} chgrp jenkins ${veracode_up_file}
