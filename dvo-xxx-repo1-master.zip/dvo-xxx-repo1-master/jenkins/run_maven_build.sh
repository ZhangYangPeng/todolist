#!/bin/sh
##
## Container Imageのビルド処理実行シェル
##
export SHELL_DIR=`dirname $0`
. ${PWD}/jenkins/init_common_env.sh


# Run Maven Container
docker run --rm -e MAVEN_OPTS="-Xmx200M" -m 500m --memory-swap 500m -v ${MAVEN_REPOSITORY}:/root/.m2 -v ${JENKINS_HOME}:/var/jenkins_home -w "$(pwd)" ${MAVEN_IMAGE_NAME_8}:${MAVEN_IMAGE_VER} mvn -B clean package

