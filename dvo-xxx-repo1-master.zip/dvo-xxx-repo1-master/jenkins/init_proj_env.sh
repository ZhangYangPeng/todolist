##
## 初期化スクリプト
##


##
##GitHub Repository info
##
export REPO="aflac-dvo-src/dvo-xxx-repo1"

##
##Jenkins PipeLine Info
##
export BDNUM=$(echo "v${BUILD_NUMBER}")
export BDID=$(echo "v${BUILD_NUMBER}")
export BDBODY="This was created by daily job"


##
## Application
##
export APPL_NAME="rest-demo"


##
## VERACODE Info
##
export VERA_APPL_NAME="ITA"
export VERA_UP_DOCKER="jenkins-veracode-01"
