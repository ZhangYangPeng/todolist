#!/bin/sh
##
## 初期化スクリプト
##


##
## Docker Volumes
##
export MAVEN_REPOSITORY=maven18-repo-proj01
export JENKINS_HOME=jenkins-home-proj01


##
##Maven Image Name
##
export MAVEN_IMAGE_NAME_7="aflac/maven-1.7"
export MAVEN_IMAGE_NAME_8="aflac/maven-1.8"


##
##Image Version
##
export JENKINS_IMAGE_VER="v2.15"
export MAVEN_IMAGE_VER="v3.5.4"
export LIBERTY_IMAGE_VER="v1"
