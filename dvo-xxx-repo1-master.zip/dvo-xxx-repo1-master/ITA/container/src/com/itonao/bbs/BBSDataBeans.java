package com.itonao.bbs;

public class BBSDataBeans {

	/////メンバ変数/////
	static final int maxItemsPerPage = 5;
	BBSItem[] bbsItems;
	int numOfItems;
	int lastIndex;

	/////コンストラクタ////
	public BBSDataBeans()
	{
		bbsItems = new BBSItem[20];
		for(int i=0; i < maxItemsPerPage; i++) {
			bbsItems[i] = new BBSItem();
		}

		if(bbsItems[0] == null) {
			return;
		}

		numOfItems = 0;
		lastIndex = 0;
	}

	/////メッセージの追加/////
	public void setItem(int index, BBSItem item)
	{
		if(index >= maxItemsPerPage) {
			return;
		}
		if (item == null) {
			return;
		}
		if(bbsItems[index] == null) {
			return;
		}
		bbsItems[index].name = item.name;
		bbsItems[index].email = item.email;
		bbsItems[index].content = item.content;
		bbsItems[index].subject = item.subject;
		bbsItems[index].deleteKey = item.deleteKey;
	}

	/////アクセスメソッド/////

	//メッセージ数
	public int getNumOfItems() {
		return numOfItems;
	}

	//投稿者名
	public String getName(int index) {
		return bbsItems[index].name;
	}

	//メールアドレス
	public String getEmail(int index) {
		return bbsItems[index].email;
	}

	//サブジェクト
	public String getSubject(int index) {
		return bbsItems[index].subject;
	}

	//内容
	public String getContent(int index) {
		return bbsItems[index].content;
	}

	//メッセージ番号
	public int getIndex(int index) {
		return bbsItems[index].index;
	}

	//次のページの最初のメッセージ番号
	public int getLastIndex() {
		return lastIndex;
	}

}
