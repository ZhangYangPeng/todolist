package com.itonao.bbs;

import java.io.UnsupportedEncodingException;

public class KanjiConv {
	public static String ConvJStr(String str) {
		if (str != null) {
			try {
				return new String(str.getBytes("8859_1"),"JISAutoDetect");
			} catch (UnsupportedEncodingException e) {
				System.out.println(e.getMessage());
				return str;
			}
		}
		else {
			return null;
		}
	}
}
