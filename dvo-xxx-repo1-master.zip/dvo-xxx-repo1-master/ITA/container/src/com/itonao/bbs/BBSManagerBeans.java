package com.itonao.bbs;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class BBSManagerBeans {

	/////メンバ変数/////
	final private String dataFilename = "bbs.dat";
	protected String dataPath;
	protected List bbsItemsNoSync;
	protected List bbsItems;
	protected String logFilename;

	/////コンストラクタ/////
	public BBSManagerBeans()
	{
		dataPath = "";
		ReadDataFile();
	}

	public BBSManagerBeans(String path)
	{
		if (path != null)
			dataPath = path;
		else
			dataPath = "";
		ReadDataFile();
	}

	/////メッセージを取得/////
	protected BBSItem GetItem(int index)
	{
		BBSItem item;
		try {
			item = (BBSItem)bbsItems.get(index);
		}
		catch(IndexOutOfBoundsException e) {
			item = null;
		}
		return item;
	}

	/////メッセージを追加/////
	public void AddItem(BBSItem item)
	{
		bbsItems.add(0,item);
		WriteDataFile();
	}

	/////メッセージを削除/////
	public void DeleteItem(int index, String DeleteKey)
	{
		BBSItem item;
		try {
			item = (BBSItem)bbsItems.get(index);
		}
		catch(IndexOutOfBoundsException e) {
			return;
		}

		if(item == null) {
			return;
		}

		if(DeleteKey.compareTo(item.deleteKey) != 0) {
			return;
		}
		bbsItems.set(index, null);
		WriteDataFile();
	}

	/////メッセージ数を取得/////
	public int GetMaxItems()
	{
		return bbsItems.size();
	}

	/////BBSDataBeansへメッセージを詰め込む/////
	public void ReadArticles(int index, BBSDataBeans bbsData)
	{
		int maxitems = GetMaxItems();
		int items = 0;
		for(int i=0; items < BBSDataBeans.maxItemsPerPage && index + i < maxitems; i++) {
			BBSItem item = GetItem(index + i);
			if (item == null)
				continue;
			item.index = index + i;
			bbsData.setItem(items,item);
			items ++;
			bbsData.numOfItems ++;
			bbsData.lastIndex = index + i;
			if(items == BBSDataBeans.maxItemsPerPage)
				break;
		}
	}


	/////ファイルからメッセージを読み込む/////
	public synchronized boolean ReadDataFile()
	{
		try {
			FileInputStream istream = new FileInputStream(dataPath+"/"+dataFilename);
			ObjectInputStream p = new ObjectInputStream(istream);
			bbsItemsNoSync = (ArrayList)p.readObject();
			bbsItems = Collections.synchronizedList(bbsItemsNoSync);
			istream.close();
		}
		catch(IOException e) {
			bbsItemsNoSync = new ArrayList();
			bbsItems = Collections.synchronizedList(bbsItemsNoSync);
			return false;
		}
		catch(ClassNotFoundException ce) {
			bbsItemsNoSync = new ArrayList();
			bbsItems = Collections.synchronizedList(bbsItemsNoSync);
			return false;
		}
		catch(Exception e) {
			System.out.println("Exception:"+e.getMessage());
		}
		return true;
	}


	/////ファイルへメッセージを書き込む/////
	public synchronized boolean WriteDataFile()
	{
		try {
			FileOutputStream ostream = new FileOutputStream(dataPath+"/"+dataFilename);
			ObjectOutputStream p = new ObjectOutputStream(ostream);
			p.writeObject(bbsItemsNoSync);
			p.flush();
			ostream.close();
		}
		catch(IOException e) {
			return false;
		}
		return true;
	}

}
