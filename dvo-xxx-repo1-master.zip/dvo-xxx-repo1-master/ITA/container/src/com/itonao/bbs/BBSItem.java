package com.itonao.bbs;

import java.io.IOException;
import java.io.Serializable;


public class BBSItem implements Serializable {

	/////メンバ変数/////
	String name;
	String email;
	String subject;
	String content;
	String deleteKey;
	int index;

	/////コンストラクタ/////
	public BBSItem()
	{
		name = "";
		email = "";
		subject = "";
		content = "";
		deleteKey = "";
		index = 0;
	}

	/////シリアライズ(保存)/////
	private void writeObject(java.io.ObjectOutputStream out) throws IOException
	{
		out.writeObject(name);
		out.writeObject(email);
		out.writeObject(subject);
		out.writeObject(content);
		out.writeObject(deleteKey);
	}

	/////シリアライズ(読み込み)/////
	private void readObject(java.io.ObjectInputStream in) throws IOException, ClassNotFoundException
	{
		name = (String)in.readObject();
		email = (String)in.readObject();
		subject = (String)in.readObject();
		content = (String)in.readObject();
		deleteKey = (String)in.readObject();
	}
}
