package com.itonao.bbs;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class BBSServlet extends HttpServlet {

///メンバ変数/////
ServletContext sc;
BBSManagerBeans bbsManager;

/////初期化/////
public void init(ServletConfig config) throws ServletException
{
super.init(config);
sc = getServletContext();

String dataPath = config.getInitParameter("datapath");
if (dataPath == null) {
dataPath = "";
}

bbsManager = (BBSManagerBeans)sc.getAttribute("bbsmanager");
if(bbsManager == null) {
bbsManager = new BBSManagerBeans(dataPath);
sc.setAttribute("bbsmanager", bbsManager);
}
}

/////POSTメソッド/////
public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
{
doGet(request, response);
}


/////GETメソッド/////
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
{
BBSDataBeans bbsData = new BBSDataBeans();

String data = request.getParameter("function");
if(data == null) {
//メッセージを読むだけ
doBBSRead(request,response,bbsData);
}
		else if (data.compareTo("WRITE") ==0) {
			//メッセージを投稿する
			doBBSWrite(request,response,bbsData);
		}
		else if (data.compareTo("DELETE") == 0) {
			//メッセージを削除する
			doBBSDelete(request,response,bbsData);
		}

		//JSPへのデータ受け渡しとフォワード
		request.setAttribute("bbsdata", bbsData);
		sc.getRequestDispatcher("/bbs.jsp").forward(request,response);
	}

	/////メッセージの削除/////
	public void doBBSDelete(HttpServletRequest request,HttpServletResponse response, BBSDataBeans bbsData) throws IOException, ServletException
	{
		String delindex = request.getParameter("delIndex");
		if(delindex == null) {
			bbsManager.ReadArticles(0, bbsData);
			return;
		}

		int index = Integer.parseInt(delindex);

		String password = request.getParameter("pwd");
		if(password == null) {
			bbsManager.ReadArticles(0,bbsData);
			return;
		}

		bbsManager.DeleteItem(index, password);
		bbsManager.ReadArticles(0, bbsData);
	}

	/////メッセージの投稿/////
	public void doBBSWrite(HttpServletRequest request,HttpServletResponse response,BBSDataBeans bbsData) throws IOException,ServletException
	{
		BBSItem item = new BBSItem();
		item.name = KanjiConv.ConvJStr(request.getParameter("name"));
		if(item.name == null)
			item.name = "";

		item.email = KanjiConv.ConvJStr(request.getParameter("email"));
		if(item.email == null)
			item.email = "";

		item.subject = KanjiConv.ConvJStr(request.getParameter("subject"));
		if(item.subject == null)
			item.subject = "";

		item.content = KanjiConv.ConvJStr(request.getParameter("content"));
		if(item.content == null)
			item.content = "";

		item.deleteKey = KanjiConv.ConvJStr(request.getParameter("pass"));
		if(item.deleteKey == null)
			item.deleteKey = "";

		bbsManager.AddItem(item);
		bbsManager.ReadArticles(0, bbsData);
	}

	/////メッセージの読み出し/////
	public void doBBSRead(HttpServletRequest request,HttpServletResponse response,BBSDataBeans bbsData) throws IOException,ServletException
	{
		int index, lastIndex;
		String strIndex = request.getParameter("index");
		if(strIndex != null) {
			index = Integer.parseInt(strIndex);
		}
		else {
			index = 0;
		}
		bbsManager.ReadArticles(index, bbsData);
	}

	public void destroy()
	{
	}

}
