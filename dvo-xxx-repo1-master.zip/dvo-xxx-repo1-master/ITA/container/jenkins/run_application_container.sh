#!/bin/bash
##
## Container Imageのビルド処理実行シェル
##


export SHELL_DIR=`dirname ${0}`
. ${SHELL_DIR}/init_proj_env.sh


#各コマンドの作成
##Dockerbuild
docker_build_cmd="docker build --build-arg "APPL_NAME=${APPL_NAME}" -t ${APPL_CONTAINER_NAMESPACE}/${APPL_NAME}:v1 ${TARGET_DIR}"


##Remove Old Container IF exists it
#暫定処置
remove_ps_cmd="docker stop ${APPL_NAME}"
remove_rm_cmd="docker rm ${APPL_NAME}"
#トライアル時のものはなぜか動かないので、コメントアウト
#remove_ps_cmd="docker ps --filter name=${APPL_NAME} | awk 'BEGIN{i=0}{i++;}END{if(i>=0)system("docker stop "${APPL_NAME}"")}'"
#remove_ps_a_cmd="docker ps -a --filter name=${APPL_NAME} | awk 'BEGIN{i=0}{i++;}END{if(i>=0)system("docker stop "${APPL_NAME}"")}' "


##docker run
docker_run_cmd="docker run -d -p ${LIBERTY_PORT}:9080 -v demo-app-boad-data:/mnt/data --name ${APPL_NAME} ${APPL_CONTAINER_NAMESPACE}/${APPL_NAME}:v1"


##sshでログインし、コマンド実行
ssh -i ~/.ssh/id_rsa ${TARGET_SFTP_USER_ENV} ${docker_build_cmd}
echo $?
ssh -i ~/.ssh/id_rsa ${TARGET_SFTP_USER_ENV} ${remove_ps_cmd}
echo $?
#ssh -i ~/.ssh/id_rsa ${TARGET_SFTP_USER_ENV} ${remove_ps_a_cmd}
#echo $?
ssh -i ~/.ssh/id_rsa ${TARGET_SFTP_USER_ENV} ${remove_rm_cmd}
echo $?
ssh -i ~/.ssh/id_rsa ${TARGET_SFTP_USER_ENV} ${docker_run_cmd}
exit 0

