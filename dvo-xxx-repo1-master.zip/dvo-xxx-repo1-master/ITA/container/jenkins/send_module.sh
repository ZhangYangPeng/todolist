#!/bin/sh
##
## Container Imageのビルド処理実行シェル
##
export SHELL_DIR=`dirname ${0}`
. ${SHELL_DIR}/init_proj_env.sh

echo ${SHELL_DIR}
echo ${SHELL_DIR}/../

#モジュールを送付
sftp ${TARGET_SFTP_USER_ENV}  << EOF 
mkdir ${TARGET_DIR} 
mput ${SHELL_DIR}/../target/${APPL_NAME}.war ${TARGET_DIR}
mput ${SHELL_DIR}/../server/server.xml ${TARGET_DIR}
mput ${SHELL_DIR}/../Dockerfile ${TARGET_DIR}
ls -l ${TARGET_DIR}
bye 
EOF 


# Build(今回は、既存のコンテナにデプロイするため、実行無)
#docker build --build-arg APPL_NAME="${APPL_NAME}" -t ${APPL_CONTAINER_NAMESPACE}/${APPL_NAME}:v1 ${SHELL_DIR}/../





