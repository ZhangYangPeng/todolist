#!/bin/bash
##
## 初期化スクリプト
##


##
##GitHub Repository info
##
export LIB_TOKEN=db9c81e20076fb1dd3d2eb0980e17aeec8fcc120
export REPO="aflac-dvo-src/dvo-xxx-repo1"

##
##Jenkins PipeLine Info
##
export BDNUM=$(echo "v${BUILD_NUMBER}")
export BDID=$(echo "v${BUILD_NUMBER}")
export BDBODY="This was created by daily job"


##
## Application
##
export APPL_NAME="rest-demo"
export APPL_CONTAINER_NAMESPACE="demo-app"
export JENKINS_CONTAINER_NAME="jenkins-dvo-06"
export TARGET_SFTP_USER_ENV="root@pdbsirap11"
export TARGET_DIR="/root/container-release"
export LIBERTY_PORT="9080"

## 
## VERACODE Info 
## 
export VERA_APPL_NAME="ITA" 
export VERA_UP_DOCKER="jenkins-veracode-01" 
