## ITA検証用ソースコード
  
### java7アプリ
maven(java7)稼働検証に使用するjava7でビルド可能なサンプルアプリ  
以下稼働確認までの手順  
1. 本体をクローン  
`git clone http://pdbsiosm01.aflac.aflac.co.jp/aflac-dvo-src/dvo-xxx-repo1.git`

2. ITA内のjava7ソースをコピーする。  
```
cp -adR dvo-xxx-repo1/ITA/java7/* dvo-xxx-repo1/.
```
3. java8ソースを削除する。
```
rm -Rd dvo-xxx-repo1/src/main
rm -Rd dvo-xxx-repo1/src/test
```
4. ビルドに使用するmavenをjava7,ver 3.6.0へ変更する。
```
sed -i s/v3.5.4/v3.6.0/g dvo-xxx-repo1/jenkins/init_common_env.sh
sed -i s/MAVEN_IMAGE_NAME_8/MAVEN_IMAGE_NAME_7/g dvo-xxx-repo1/jenkins/run_maven_build.sh
```
5. ディレクトリ移動
```
cd dvo-xxx-repo1
```
4. ブランチ作成  
```
git branch java7
```
5. ベース変更  
```
git checkout java7
```
6. コミット  
```
git commit -a
```
7. プッシュ  
```
git push origin java7
```
8. jnekinsの宛先変更  
```
*/master→*/java7
```
9. JOB実行  
Jenkins http://pdbsircc11:8080/job/ita-test-daily-maven17/  
10. Open Libertyへデプロイし、稼働確認  
  
  
  
### デモ用アプリ
部長会デモで使用した掲示板アプリ。ビルド→デプロイまでを自動化。  
以下デモまでの手順。  
1. 本体をクローン  
`git clone http://pdbsiosm01.aflac.aflac.co.jp/aflac-dvo-src/dvo-xxx-repo1.git`
2. ITA内をコピー  
```
cp -adR dvo-xxx-repo1/ITA/container/* dvo-xxx-repo1/
```
3. 実行権限を変更  
```
chmod 740 dvo-xxx-repo1/jenkins/*
```
4. ブランチ作成  
```
git branch demo-app
```
5. ベース変更  
```
git checkout demo-app
```
6. コミット  
```
git commit -a
```
7. プッシュ  
```
git push origin demo-app
```
8. jnekinsの宛先変更  
```
*/master→*/demo-app
```
9. JOB実行  
Jenkins http://pdbsircc11:8080/job/demo-app-job/  
10. 稼働確認  
掲示板:http://pdbsirap11:9080/rest-demo/bbs.jsp  
