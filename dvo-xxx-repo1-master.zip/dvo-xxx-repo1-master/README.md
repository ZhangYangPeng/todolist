### サンプルアプリケーション
デモ環境用のサンプルアプリケーションです。
  
実行方法  

```
curl http://XXX(接続先のホスト名、もしくはIP):XXX(使用ポート)/rest-demo/biz/contract/retrieve -X POST -d '{"cid":"11111"}' -H "Content-Type: application/json"
```

JSON形式の応答データ（下記）が戻れば正常に稼働しています。

```
{
  "cid": "11111",
  "name": "田中一郎",
  "mail": "tanaka@sample.com"
}

```
